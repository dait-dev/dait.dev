declare namespace NodeJS {
  interface ProcessEnv {
    NEXT_PUBLIC_AUTH_CID: string
    NEXT_PUBLIC_GOOGLE_CID: string
  }
}
