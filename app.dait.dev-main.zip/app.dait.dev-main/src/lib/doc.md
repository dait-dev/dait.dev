# Lib

Used for sharing functions/methods across ui components

# Lib vs utils

Lib: is primarily for sharing logic for ui components strictly Utils: includes typescript
code that can be leveraged in both ui, be(apis)
