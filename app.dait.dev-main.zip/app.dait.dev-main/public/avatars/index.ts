import avatar from './avatar.png'
import avatar1 from './avatar-1.png'
import avatar2 from './avatar-2.png'
import avatar3 from './avatar-3.png'
import avatar4 from './avatar-4.png'
import avatar5 from './avatar-5.png'

const avatars = { avatar, avatar1, avatar2, avatar3, avatar4, avatar5 }

export default avatars
