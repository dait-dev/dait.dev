declare module 'web3.storage'
declare module '@particle-network/auth'
